import {
  apiGetUserInfo
} from './api/user'
import {
  setToken
} from './utils/storage'
App({
  onLaunch() {
    // setToken('eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjMiLCJleHAiOjE2NDgwMjE5MzksImlhdCI6MTY0NzY2MTkzOX0.xyK-TEtcQNxOFpNxXXRG9jmOenwXD5C-4n1p8Z5T-Y0')
    // apiGetUserInfo()
  },
  globalData: {}
})
