const mConfig = {
  BASEURL: 'http://192.168.30.10:8080/api',
  HTTP_STATUS: {
    success: 200,
    error: 500
  }
}
export default mConfig
